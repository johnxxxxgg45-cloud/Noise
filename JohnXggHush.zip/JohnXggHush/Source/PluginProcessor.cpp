#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <algorithm>
#include <cmath>
#include <iterator>
#include <vector>

namespace
{
    struct Preset { const char* name; float thr, sens, gate; int type; };
    const Preset factory[] = {
        { "Hot Solo",              .55f, .50f, .60f, 1 },
        { "High Gain",             .65f, .60f, .75f, 0 },
        { "Clean Hiss",            .40f, .35f, .40f, 3 },
        { "Metal Tight",           .75f, .55f, .90f, 2 },
        { "Pedalboard Barulhento", .70f, .75f, .70f, 1 },
        { "Humbucker Suave",       .50f, .45f, .50f, 0 },
        { "Baixo Limpo",           .35f, .30f, .45f, 3 },
    };
    const float REL[4] = { .08f, .16f, .04f, .20f };
    const float RAT[4] = { 2.5f, 2.0f, 4.0f, 2.0f };
}

using F = juce::AudioParameterFloat;
using B = juce::AudioParameterBool;

juce::AudioProcessorValueTreeState::ParameterLayout HushProcessor::makeLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout l;
    auto f = [&](const juce::String& id, const juce::String& n, float d) {
        l.add(std::make_unique<F>(juce::ParameterID { id, 1 }, n, juce::NormalisableRange<float>(0.f, 1.f), d)); };
    for (juce::String c : { "A", "B" })
    {
        f("thr" + c, "Expander Threshold " + c, .55f);
        f("sens" + c, "Filter Sensitivity " + c, .5f);
        l.add(std::make_unique<B>(juce::ParameterID { "lev" + c, 1 }, "Level +4dB " + c, true));
    }
    l.add(std::make_unique<B>(juce::ParameterID { "link", 1 }, "Master Link", true));
    l.add(std::make_unique<B>(juce::ParameterID { "bypass", 1 }, "Bypass", false));
    l.add(std::make_unique<B>(juce::ParameterID { "hq", 1 }, "HQ", false));
    f("gate", "Gate", .6f); f("inGain", "In", .5f); f("outGain", "Out", .5f); f("mix", "Mix", 1.f);
    l.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID { "type", 1 }, "Type",
          juce::StringArray { "Default", "Lead", "Rhythm Tight", "Clean" }, 0));
    return l;
}

HushProcessor::HushProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "STATE", makeLayout())
{
    auto g = [&](const juce::String& id) { return apvts.getRawParameterValue(id); };
    thrP[0] = g("thrA"); thrP[1] = g("thrB"); sensP[0] = g("sensA"); sensP[1] = g("sensB");
    levP[0] = g("levA"); levP[1] = g("levB"); linkP = g("link"); bypP = g("bypass"); hqP = g("hq");
    gateP = g("gate"); inP = g("inGain"); outP = g("outGain"); mixP = g("mix"); typeP = g("type");
    for (int i = 0; i < 2; ++i) { gr[i] = 0; fc[i] = 20000; inPk[i] = 0; outPk[i] = 0; }
    apvts.state.setProperty("presetName", "Hot Solo", nullptr);
}

bool HushProcessor::isBusesLayoutSupported(const BusesLayout& l) const
{
    auto o = l.getMainOutputChannelSet();
    return o == l.getMainInputChannelSet() && (o == juce::AudioChannelSet::mono() || o == juce::AudioChannelSet::stereo());
}

void HushProcessor::resetState()
{
    for (auto& c : ch) c = Chan();
    if (os) os->reset();
}

void HushProcessor::updateLatency()
{
    int look = (int) std::round(.001 * sr);
    int extra = (lastHq && os) ? (int) std::ceil(os->getLatencyInSamples()) : 0;
    setLatencySamples(look + extra);
}

void HushProcessor::prepareToPlay(double rate, int block)
{
    sr = rate; maxBlock = std::max(block, 64);
    os = std::make_unique<juce::dsp::Oversampling<float>>(2, 1,
            juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR, true, false);
    os->initProcessing((size_t) maxBlock);
    lastHq = *hqP > .5f;
    resetState(); updateLatency();
}

void HushProcessor::runCore(juce::dsp::AudioBlock<float>& b, double fs)
{
    const float kA = 1.f - std::exp(-1.f / (float) (fs * .0004)), kR = 1.f - std::exp(-1.f / (float) (fs * .06));
    const int t = juce::jlimit(0, 3, (int) *typeP);
    const float gO = 1.f - std::exp(-1.f / (float) (fs * .001)), gC = 1.f - std::exp(-1.f / (float) (fs * REL[t]));
    const float fO = gO, fC = 1.f - std::exp(-1.f / (float) (fs * .03));
    const float inG = std::pow(10.f, ((*inP) - .5f) * 24.f / 20.f), outG = std::pow(10.f, ((*outP) - .5f) * 24.f / 20.f);
    const float maxGR = 10.f + (*gateP) * 50.f, rat = RAT[t], mix = *mixP;
    const bool byp = *bypP > .5f, link = *linkP > .5f;
    const int look = (int) std::round(.001 * fs);
    const size_t n = b.getNumSamples();

    for (size_t c = 0; c < b.getNumChannels() && c < 2; ++c)
    {
        auto& s = ch[c];
        const int q = (link && c == 1) ? 0 : (int) c;
        const float thr = -75.f + (*thrP[q]) * 50.f, sn = -70.f + (*sensP[q]) * 50.f;
        const float det = (*levP[q] > .5f) ? 1.f : .2f;
        float* d = b.getChannelPointer(c);
        float pin = 0, pout = 0;
        for (size_t i = 0; i < n; ++i)
        {
            const float raw = d[i];
            const float x = raw * inG;
            s.dl[s.w] = x;
            const float xd = s.dl[(s.w - look) & 1023];
            s.w = (s.w + 1) & 1023;
            const float a = std::abs(x) * det;
            s.env += (a - s.env) * (a > s.env ? kA : kR);
            const float db = 20.f * std::log10(s.env + 1e-9f);
            float grd = 0.f;
            if (db < thr) grd = std::min((thr - db) * (rat - 1.f), maxGR);
            const float tg = std::pow(10.f, -grd / 20.f);
            s.g += (tg - s.g) * (tg > s.g ? gO : gC);
            const float ft = db > sn ? 20000.f : std::max(700.f, 20000.f * std::pow(10.f, -(sn - db) * .05f));
            s.fc += (ft - s.fc) * (ft > s.fc ? fO : fC);
            const float a2 = std::min(.95f, 6.2832f * s.fc / (float) fs);
            s.y1 += a2 * (xd - s.y1);
            s.y2 += a2 * (s.y1 - s.y2);
            const float wet = s.y2 * s.g * outG, dry = xd * outG;
            const float out = byp ? dry : wet * mix + dry * (1.f - mix);
            d[i] = out;
            pin = std::max(pin, std::abs(raw)); pout = std::max(pout, std::abs(out));
        }
        s.gr = -20.f * std::log10(std::max(s.g, 1e-4f));
        gr[c] = s.gr; fc[c] = s.fc;
        inPk[c] = std::max(inPk[c].load(), pin); outPk[c] = std::max(outPk[c].load(), pout);
    }
}

void HushProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals nd;
    const bool hq = *hqP > .5f;
    if (hq != lastHq) { lastHq = hq; resetState(); updateLatency(); }
    const int nCh = juce::jmin(2, buffer.getNumChannels());
    juce::dsp::AudioBlock<float> all(buffer);
    for (size_t start = 0; start < all.getNumSamples(); start += (size_t) maxBlock)
    {
        auto len = std::min((size_t) maxBlock, all.getNumSamples() - start);
        auto sub = all.getSubBlock(start, len).getSubsetChannelBlock(0, (size_t) nCh);
        if (hq && os)
        {
            auto up = os->processSamplesUp(sub);
            runCore(up, sr * 2.0);
            os->processSamplesDown(sub);
        }
        else runCore(sub, sr);
    }
}

juce::File HushProcessor::presetDir() const
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("John xgg/Hush Presets");
}
int HushProcessor::numFactory() const { return (int) std::size(factory); }
juce::String HushProcessor::getPresetName() const { return apvts.state.getProperty("presetName", "Hot Solo").toString(); }

juce::StringArray HushProcessor::getPresetNames()
{
    juce::StringArray n;
    for (auto& f : factory) n.add(f.name);
    auto files = presetDir().findChildFiles(juce::File::findFiles, false, "*.xml");
    std::vector<juce::File> v(files.begin(), files.end());
    std::sort(v.begin(), v.end(), [](const juce::File& a, const juce::File& b) { return a.getFileName().compareIgnoreCase(b.getFileName()) < 0; });
    for (auto& f : v) n.add(f.getFileNameWithoutExtension());
    return n;
}

void HushProcessor::setP(const juce::String& id, float real)
{
    if (auto* p = apvts.getParameter(id)) p->setValueNotifyingHost(p->convertTo0to1(real));
}

void HushProcessor::loadPreset(int idx)
{
    auto names = getPresetNames();
    if (idx < 0 || idx >= names.size()) return;
    if (idx < numFactory())
    {
        auto& f = factory[idx];
        for (juce::String c : { "A", "B" }) { setP("thr" + c, f.thr); setP("sens" + c, f.sens); setP("lev" + c, 1.f); }
        setP("gate", f.gate); setP("type", (float) f.type); setP("link", 1.f); setP("bypass", 0.f);
        setP("inGain", .5f); setP("outGain", .5f); setP("mix", 1.f);
    }
    else
    {
        auto file = presetDir().getChildFile(names[idx] + ".xml");
        if (auto xml = juce::XmlDocument::parse(file))
        {
            float keepHq = *hqP;
            apvts.replaceState(juce::ValueTree::fromXml(*xml));
            setP("hq", keepHq);
        }
    }
    apvts.state.setProperty("presetName", names[idx], nullptr);
}

void HushProcessor::savePreset(const juce::String& name)
{
    auto n = juce::File::createLegalFileName(name.trim());
    if (n.isEmpty()) return;
    presetDir().createDirectory();
    apvts.state.setProperty("presetName", n, nullptr);
    if (auto xml = apvts.copyState().createXml()) xml->writeTo(presetDir().getChildFile(n + ".xml"));
}

bool HushProcessor::deletePreset(const juce::String& name)
{
    auto f = presetDir().getChildFile(name + ".xml");
    return f.existsAsFile() && f.deleteFile();
}

void HushProcessor::randomize()
{
    juce::Random r;
    float thr = .3f + r.nextFloat() * .5f, sens = .3f + r.nextFloat() * .5f;
    for (juce::String c : { "A", "B" }) { setP("thr" + c, thr); setP("sens" + c, sens); }
    setP("gate", .3f + r.nextFloat() * .65f);
    apvts.state.setProperty("presetName", juce::String::fromUTF8("Aleatório"), nullptr);
}

void HushProcessor::getStateInformation(juce::MemoryBlock& d)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, d);
}
void HushProcessor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size))
        if (xml->hasTagName(apvts.state.getType())) apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessorEditor* HushProcessor::createEditor() { return new HushEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new HushProcessor(); }
