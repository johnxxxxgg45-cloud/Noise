#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <atomic>

class HushProcessor : public juce::AudioProcessor
{
public:
    HushProcessor();
    void prepareToPlay(double, int) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "John xgg Hush"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    juce::StringArray getPresetNames();
    int numFactory() const;
    juce::String getPresetName() const;
    void loadPreset(int index);
    void savePreset(const juce::String& name);
    bool deletePreset(const juce::String& name);
    void randomize();
    juce::File presetDir() const;

    juce::AudioProcessorValueTreeState apvts;
    std::atomic<float> gr[2], fc[2], inPk[2], outPk[2];

private:
    struct Chan { float env = 0, g = 1, fc = 20000, y1 = 0, y2 = 0, gr = 0; float dl[1024] {}; int w = 0; };
    static juce::AudioProcessorValueTreeState::ParameterLayout makeLayout();
    void setP(const juce::String& id, float real);
    void runCore(juce::dsp::AudioBlock<float>& b, double fs);
    void resetState();
    void updateLatency();

    Chan ch[2];
    std::unique_ptr<juce::dsp::Oversampling<float>> os;
    double sr = 44100.0;
    int maxBlock = 512;
    bool lastHq = false;
    std::atomic<float> *thrP[2], *sensP[2], *levP[2], *linkP, *bypP, *hqP, *gateP, *inP, *outP, *mixP, *typeP;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(HushProcessor)
};
