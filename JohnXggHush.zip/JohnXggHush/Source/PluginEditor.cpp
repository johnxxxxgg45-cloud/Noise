#include "PluginEditor.h"
#include "BinaryData.h"
#include <cmath>

static const int W = 1000, H = 766;

HushEditor::HushEditor(HushProcessor& proc) : AudioProcessorEditor(&proc), p(proc)
{
    bg = juce::ImageCache::getFromMemory(BinaryData::fundo_jpg, BinaryData::fundo_jpgSize);
    setSize(W, H);
    setResizable(false, false);

    for (int c = 0; c < 2; ++c)
    {
        juce::String L = c ? "B" : "A";
        initKnob(thr[c], "thr" + L, 50); initKnob(sens[c], "sens" + L, 50);
        initBtn(lv[c], "+4 dB", true); lv[c].setClickingTogglesState(true);
        aLv[c] = std::make_unique<APVTS::ButtonAttachment>(p.apvts, "lev" + L, lv[c]);
    }
    initKnob(gate, "gate", 44); initKnob(inG, "inGain", 44); initKnob(outG, "outGain", 44); initKnob(mix, "mix", 44);

    for (int i = 0; i < 16; ++i)
    {
        bool red = (i % 8) < 4;
        leds[(size_t) i].onC = red ? juce::Colour(0xffff3b30) : juce::Colour(0xff47e04a);
        leds[(size_t) i].offC = red ? juce::Colour(0xff2c0b0b) : juce::Colour(0xff0b2c0b);
        addAndMakeVisible(leds[(size_t) i]);
    }
    bypLed.onC = juce::Colour(0xffff3b30); bypLed.offC = juce::Colour(0xff2c0b0b); addAndMakeVisible(bypLed);

    initBtn(hq, "HQ", false); hq.setClickingTogglesState(true);
    initBtn(rnd, "RND", false); initBtn(rst, "RST", false); initBtn(prev, "<", false); initBtn(next, ">", false);
    initBtn(save, "SAVE", false); initBtn(del, "DEL", false);
    initBtn(lk, "MASTER", true); lk.setClickingTogglesState(true);
    initBtn(byp, "BYPASS", true); byp.setClickingTogglesState(true);
    aHq = std::make_unique<APVTS::ButtonAttachment>(p.apvts, "hq", hq);
    aLk = std::make_unique<APVTS::ButtonAttachment>(p.apvts, "link", lk);
    aByp = std::make_unique<APVTS::ButtonAttachment>(p.apvts, "bypass", byp);

    rnd.onClick = [this] { p.randomize(); };
    rst.onClick = [this] { auto n = p.getPresetNames(); int i = n.indexOf(p.getPresetName()); p.loadPreset(i < 0 ? 0 : i); };
    prev.onClick = [this] { step(-1); };
    next.onClick = [this] { step(1); };
    save.onClick = [this]
    {
        auto* aw = new juce::AlertWindow("Salvar preset", "Nome do preset:", juce::MessageBoxIconType::NoIcon);
        aw->addTextEditor("n", p.getPresetName());
        aw->addButton("Salvar", 1, juce::KeyPress(juce::KeyPress::returnKey));
        aw->addButton("Cancelar", 0, juce::KeyPress(juce::KeyPress::escapeKey));
        juce::Component::SafePointer<HushEditor> safe(this);
        aw->enterModalState(true, juce::ModalCallbackFunction::create([safe, aw](int r)
        {
            if (r == 1 && safe != nullptr) safe->p.savePreset(aw->getTextEditorContents("n"));
            delete aw;
        }), false);
    };
    del.onClick = [this]
    {
        auto n = p.getPresetName(); auto names = p.getPresetNames();
        if (names.indexOf(n) < p.numFactory()) {
            juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::InfoIcon, "Apagar preset", "Presets de fábrica não podem ser apagados.");
            return; }
        if (p.deletePreset(n)) p.loadPreset(0);
    };

    type.addItemList({ "Default", "Lead", "Rhythm Tight", "Clean" }, 1);
    type.setColour(juce::ComboBox::backgroundColourId, juce::Colours::black);
    type.setColour(juce::ComboBox::textColourId, juce::Colours::white);
    type.setColour(juce::ComboBox::outlineColourId, juce::Colours::white);
    type.setColour(juce::ComboBox::arrowColourId, juce::Colours::white);
    addAndMakeVisible(type);
    aType = std::make_unique<APVTS::ComboBoxAttachment>(p.apvts, "type", type);

    nameL.setJustificationType(juce::Justification::centred);
    nameL.setColour(juce::Label::textColourId, juce::Colours::white);
    nameL.setFont(juce::Font(juce::FontOptions(22.f)));
    addAndMakeVisible(nameL);
    startTimerHz(30);
}

HushEditor::~HushEditor()
{
    for (auto* s : { &thr[0].s, &thr[1].s, &sens[0].s, &sens[1].s, &gate.s, &inG.s, &outG.s, &mix.s }) s->setLookAndFeel(nullptr);
}

void HushEditor::initKnob(Knob& k, const juce::String& id, int)
{
    k.s.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    k.s.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    k.s.setRotaryParameters(-2.356f, 2.356f, true);
    k.s.setMouseDragSensitivity(150);
    k.s.setLookAndFeel(&lnf);
    addAndMakeVisible(k.s);
    k.a = std::make_unique<APVTS::SliderAttachment>(p.apvts, id, k.s);
}

void HushEditor::initBtn(juce::TextButton& b, const juce::String& text, bool solid)
{
    b.setButtonText(text);
    using T = juce::TextButton;
    if (solid)
    {
        b.setColour(T::buttonColourId, juce::Colour(0xffbbbbbb)); b.setColour(T::buttonOnColourId, juce::Colour(0xff7dff7d));
        b.setColour(T::textColourOffId, juce::Colours::black); b.setColour(T::textColourOnId, juce::Colours::black);
    }
    else
    {
        b.setColour(T::buttonColourId, juce::Colours::transparentBlack); b.setColour(T::buttonOnColourId, juce::Colours::transparentBlack);
        b.setColour(T::textColourOffId, juce::Colour(0xffcfcfcf)); b.setColour(T::textColourOnId, juce::Colour(0xff7dff7d));
    }
    addAndMakeVisible(b);
}

void HushEditor::step(int d)
{
    auto n = p.getPresetNames(); int i = n.indexOf(p.getPresetName()); if (i < 0) i = 0;
    p.loadPreset((i + d + n.size()) % n.size());
}

void HushEditor::resized()
{
    auto at = [](juce::Component& c, int cx, int cy, int w, int h) { c.setBounds(cx - w / 2, cy - h / 2, w, h); };
    panel = { 115, 199, 770, 337 };
    auto in = panel.reduced(8); const int gap = 5;
    float c1 = in.getWidth() * .07f, c4 = in.getWidth() * .12f, c5 = in.getWidth() * .17f;
    float fr = (in.getWidth() - c1 - c4 - c5 - 4 * gap) / 2.f;
    float rowH = (in.getHeight() - gap) / 2.f;
    int x1 = in.getX(), x2 = x1 + (int) c1 + gap, x3 = x2 + (int) fr + gap, x4 = x3 + (int) fr + gap, x5 = x4 + (int) c4 + gap;
    for (int r = 0; r < 2; ++r)
    {
        int y = in.getY() + r * ((int) rowH + gap);
        chR[r] = { x1, y, (int) c1, (int) rowH };
        box[r][0] = { x2, y, (int) fr, (int) rowH };
        box[r][1] = { x3, y, (int) fr, (int) rowH };
        for (int j = 0; j < 2; ++j)
        {
            auto b = box[r][j]; int cy = b.getCentreY();
            (j == 0 ? thr[r] : sens[r]).s.setBounds(b.getRight() - 58, cy - 25, 50, 50);
            for (int k = 0; k < 4; ++k)
                leds[(size_t) (r * 8 + j * 4 + k)].setBounds(b.getX() + 56 + k * 24, cy - 14, 16, 16);
        }
        at(lv[r], x4 + (int) c4 / 2, y + (int) rowH / 2, 74, 28);
    }
    sideR = { x5, in.getY(), (int) c5, in.getHeight() };
    at(lk, sideR.getCentreX(), sideR.getCentreY() - 18, 92, 28);
    at(bypLed, sideR.getX() + 14, sideR.getCentreY() + 34, 20, 20);
    at(byp, sideR.getCentreX() + 12, sideR.getCentreY() + 34, 84, 28);

    const int ty = 28;
    at(hq, 225, ty, 46, 24); at(rnd, 269, ty, 46, 24); at(rst, 310, ty, 46, 24); at(prev, 354, ty, 36, 24);
    at(next, 670, ty, 36, 24); at(save, 716, ty, 50, 24); at(del, 764, ty, 46, 24);
    at(nameL, 500, ty, 300, 30);
    at(type, 345, 718, 170, 28);
    at(gate.s, 424, 721, 44, 44); at(inG.s, 502, 721, 44, 44); at(outG.s, 592, 721, 44, 44); at(mix.s, 682, 721, 44, 44);
}

void HushEditor::paint(juce::Graphics& g)
{
    g.drawImage(bg, getLocalBounds().toFloat());
    g.setColour(juce::Colour(0xffdddddd)); g.setFont(13.f);
    g.drawText(juce::String::fromUTF8("Registrado para: John xgg"), 350, 46, 300, 18, juce::Justification::centred);

    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff262626), 0, (float) panel.getY(), juce::Colour(0xff121212), 0, (float) panel.getBottom(), false));
    g.fillRoundedRectangle(panel.toFloat(), 5.f);
    g.setColour(juce::Colour(0xff444444)); g.drawRoundedRectangle(panel.toFloat(), 5.f, 2.f);

    const char* t1[2] = { "EXPANDER", "FILTER" }; const char* t2[2] = { "GR dB", "kHz" };
    const int cap[2][4] = { { 30, 20, 10, 5 }, { 1, 4, 10, 20 } };
    for (int r = 0; r < 2; ++r)
    {
        g.setColour(juce::Colour(0xffdddddd)); g.setFont(24.f);
        g.drawText(r ? "B" : "A", chR[r], juce::Justification::centred);
        for (int j = 0; j < 2; ++j)
        {
            auto b = box[r][j];
            g.setColour(juce::Colour(0xff1d5fd0)); g.fillRoundedRectangle(b.toFloat(), 3.f);
            g.setColour(juce::Colours::white); g.setFont(11.f);
            g.drawText(t1[j], b.getX() + 4, b.getCentreY() - 22, 56, 14, juce::Justification::centredLeft);
            g.drawText(t2[j], b.getX() + 4, b.getCentreY() - 8, 56, 14, juce::Justification::centredLeft);
            g.setFont(10.f);
            for (int k = 0; k < 4; ++k)
                g.drawText(juce::String(cap[j][k]), b.getX() + 52 + k * 24, b.getCentreY() + 4, 24, 12, juce::Justification::centred);
        }
    }
    g.setColour(juce::Colour(0xffdddddd)); g.setFont(15.f);
    g.drawText("HUSH - xgg", sideR.getX(), sideR.getY() + 10, sideR.getWidth(), 20, juce::Justification::centred);
    g.setFont(12.f);
    g.drawText("TYPE", 260, 680, 170, 16, juce::Justification::centred);
    const char* kl[4] = { "GATE", "IN", "OUT", "MIX" }; const int kx[4] = { 424, 502, 592, 682 };
    for (int i = 0; i < 4; ++i) g.drawText(kl[i], kx[i] - 30, 680, 60, 16, juce::Justification::centred);

    const int bx[4] = { 73, 96, 897, 918 };
    for (int i = 0; i < 4; ++i)
    {
        juce::Rectangle<float> r((float) bx[i], 235.f, 10.f, 422.f);
        g.setColour(juce::Colour(0xff0a0a0a)); g.fillRect(r);
        float db = 20.f * std::log10(shown[i] + 1e-5f);
        float f = juce::jlimit(0.f, 1.f, (db + 60.f) / 60.f);
        auto fill = r.withTrimmedTop(r.getHeight() * (1.f - f));
        g.setGradientFill(juce::ColourGradient(juce::Colour(0xffa8d800), 0, r.getY(), juce::Colour(0xff14c814), 0, r.getY() + r.getHeight() * .3f, false));
        g.fillRect(fill);
    }
}

void HushEditor::timerCallback()
{
    const bool link = *p.apvts.getRawParameterValue("link") > .5f, byp_ = *p.apvts.getRawParameterValue("bypass") > .5f;
    const int rv[4] = { 30, 20, 10, 5 }, gv[4] = { 1000, 4000, 10000, 20000 };
    for (int c = 0; c < 2; ++c)
    {
        float gr = p.gr[c], fc = p.fc[c];
        for (int k = 0; k < 4; ++k)
        {
            leds[(size_t) (c * 8 + k)].on = !byp_ && gr >= rv[k] * .9f;
            leds[(size_t) (c * 8 + 4 + k)].on = fc >= gv[k] * .95f;
            leds[(size_t) (c * 8 + k)].repaint(); leds[(size_t) (c * 8 + 4 + k)].repaint();
        }
        lv[c].setButtonText(lv[c].getToggleState() ? "+4 dB" : "-10 dB");
    }
    for (auto* k : { &thr[1], &sens[1] }) k->s.setAlpha(link ? .45f : 1.f);
    bypLed.on = byp_; bypLed.repaint();
    shown[0] = std::max(shown[0] * .85f, p.inPk[0].exchange(0.f));
    shown[1] = std::max(shown[1] * .85f, p.inPk[1].exchange(0.f));
    shown[2] = std::max(shown[2] * .85f, p.outPk[0].exchange(0.f));
    shown[3] = std::max(shown[3] * .85f, p.outPk[1].exchange(0.f));
    if (nameL.getText() != p.getPresetName()) nameL.setText(p.getPresetName(), juce::dontSendNotification);
    repaint(60, 230, 880, 440); repaint(60, 230, 60, 440);
}
