#pragma once
#include "PluginProcessor.h"
#include <array>
#include <memory>

struct KnobLnF : juce::LookAndFeel_V4
{
    void drawRotarySlider(juce::Graphics& g, int x, int y, int w, int h, float pos, float a0, float a1, juce::Slider&) override
    {
        auto r = juce::Rectangle<float>((float) x, (float) y, (float) w, (float) h).reduced(2.f);
        auto c = r.getCentre(); float rad = r.getWidth() * .5f;
        g.setGradientFill(juce::ColourGradient(juce::Colour(0xff5a5a5a), c.x - rad * .3f, c.y - rad * .4f,
                                               juce::Colour(0xff101010), c.x + rad * .6f, c.y + rad * .7f, true));
        g.fillEllipse(r);
        g.setColour(juce::Colour(0xff8c8c8c)); g.drawEllipse(r, 2.f);
        float ang = a0 + pos * (a1 - a0);
        juce::Path p; p.addRoundedRectangle(-2.f, -rad + 4.f, 4.f, rad * .42f, 2.f);
        g.setColour(juce::Colours::white);
        g.fillPath(p, juce::AffineTransform::rotation(ang).translated(c));
    }
};

class HushEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit HushEditor(HushProcessor&);
    ~HushEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    using APVTS = juce::AudioProcessorValueTreeState;
    struct Led : juce::Component
    {
        bool on = false; juce::Colour onC, offC;
        void paint(juce::Graphics& g) override
        {
            auto r = getLocalBounds().toFloat().reduced(2.f);
            if (on) { g.setColour(onC.withAlpha(.35f)); g.fillEllipse(r.expanded(2.f)); }
            g.setColour(on ? onC : offC); g.fillEllipse(r);
        }
    };
    struct Knob { juce::Slider s; std::unique_ptr<APVTS::SliderAttachment> a; };

    void initKnob(Knob& k, const juce::String& id, int size);
    void initBtn(juce::TextButton& b, const juce::String& text, bool solid);
    void step(int d);
    void timerCallback() override;

    HushProcessor& p;
    KnobLnF lnf;
    juce::Image bg;
    Knob thr[2], sens[2], gate, inG, outG, mix;
    std::array<Led, 16> leds;
    Led bypLed;
    juce::TextButton hq, rnd, rst, prev, next, save, del, lk, byp, lv[2];
    juce::ComboBox type;
    juce::Label nameL;
    std::unique_ptr<APVTS::ButtonAttachment> aHq, aLk, aByp, aLv[2];
    std::unique_ptr<APVTS::ComboBoxAttachment> aType;
    juce::Rectangle<int> panel, box[2][2], chR[2], sideR;
    float shown[4] {};

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(HushEditor)
};
