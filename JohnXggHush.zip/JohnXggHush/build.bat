@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === John xgg Hush - build ===
where cmake >nul 2>nul
if errorlevel 1 (
  echo CMake nao encontrado. Instale em https://cmake.org/download e marque "Add to PATH".
  pause & exit /b 1
)
cmake -S . -B build -A x64
if errorlevel 1 goto erro
cmake --build build --config Release --parallel
if errorlevel 1 goto erro
if exist Saida rmdir /s /q Saida
mkdir Saida
xcopy /e /i /y "build\JohnXggHush_artefacts\Release\VST3" "Saida\VST3" >nul
xcopy /e /i /y "build\JohnXggHush_artefacts\Release\Standalone" "Saida\Standalone" >nul
echo.
echo PRONTO! Arquivos na pasta "Saida".
echo Copie "Saida\VST3\John xgg Hush.vst3" para C:\Program Files\Common Files\VST3
pause
exit /b 0
:erro
echo.
echo ERRO no build. Confira se o Visual Studio (Desktop development with C++) esta instalado.
pause
exit /b 1
