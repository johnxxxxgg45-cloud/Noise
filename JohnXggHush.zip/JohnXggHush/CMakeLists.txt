cmake_minimum_required(VERSION 3.22)
project(JohnXggHush VERSION 1.0.0)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
include(FetchContent)
FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git GIT_TAG 8.0.6 GIT_SHALLOW ON)
FetchContent_MakeAvailable(JUCE)

juce_add_plugin(JohnXggHush
    COMPANY_NAME "John xgg"
    PLUGIN_MANUFACTURER_CODE Jxgg
    PLUGIN_CODE Hush
    FORMATS VST3 Standalone
    PRODUCT_NAME "John xgg Hush"
    BUNDLE_ID com.johnxgg.hush
    IS_SYNTH FALSE NEEDS_MIDI_INPUT FALSE NEEDS_MIDI_OUTPUT FALSE
    COPY_PLUGIN_AFTER_BUILD FALSE
    VST3_CATEGORIES Fx Dynamics)

juce_add_binary_data(JohnXggAssets SOURCES Assets/fundo.jpg)

target_sources(JohnXggHush PRIVATE Source/PluginProcessor.cpp Source/PluginEditor.cpp)
target_compile_definitions(JohnXggHush PUBLIC JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JUCE_VST3_CAN_REPLACE_VST2=0 JUCE_DISPLAY_SPLASH_SCREEN=0)
target_link_libraries(JohnXggHush PRIVATE JohnXggAssets juce::juce_audio_utils juce::juce_dsp
    PUBLIC juce::juce_recommended_config_flags juce::juce_recommended_lto_flags)
